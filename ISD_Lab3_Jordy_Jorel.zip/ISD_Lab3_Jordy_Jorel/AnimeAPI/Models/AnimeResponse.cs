﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace AnimeAPI.Models
{
    public class AnimeResponse
    {
        [JsonProperty("data")]
        public Data data {  get; set; }
    }
}
