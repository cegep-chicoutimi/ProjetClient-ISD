﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace AnimeAPI.Models
{
    public class CoverImage
    {
        [JsonProperty(PropertyName = "original")]
        public string? ImageUrl { get; set; }
    }
}
