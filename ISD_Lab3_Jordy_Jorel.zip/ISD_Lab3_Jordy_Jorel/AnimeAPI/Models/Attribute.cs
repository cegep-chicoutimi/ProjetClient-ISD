﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace AnimeAPI.Models
{
    public class Attribute
    {
        [JsonProperty(PropertyName = "synopsis")]
        public string Synopsis { get; set; }

        [JsonProperty(PropertyName = "titles")]
        public Title Title { get; set; }

        [JsonProperty(PropertyName = "startDate")]
        public DateTime StartDate { get; set; }

        [JsonProperty(PropertyName = "endDate")]
        public DateTime EndDate { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        [JsonProperty(PropertyName = "posterImage")]
        public PosterImage ImagePost { get; set; }

        [JsonProperty(PropertyName = "coverImage")]
        public CoverImage? ImageCover { get; set; }

        [JsonProperty(PropertyName = "youtubeVideoId")]
        public string? UrlVideo { get; set; }
    }
}
