﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AnimeAPI.Models;
using Newtonsoft.Json;
using static System.Net.WebRequestMethods;

namespace AnimeAPI
{
    public class AnimeProcessor
    {


        //Mon API ne prenais pas en consideration le code normal du coup vous avis écrit celui ci 
        public async static Task<AnimeResponse> Connection(string id, string tag)
        {
            string url;

            if(id == "")
            {
                 url = $"https://kitsu.io/api/edge/{tag}/10741";
            }

            else
            {
                 url = $"https://kitsu.io/api/edge/{tag}/{id}";
            }


            using (Task<HttpResponseMessage> response = ApiHelper.ApiClient.GetAsync(url))
            {
                if (response.Result.IsSuccessStatusCode)
                {
                    string temp = await response.Result.Content.ReadAsStringAsync();
                    AnimeResponse anime = JsonConvert.DeserializeObject<AnimeResponse>(temp);


                    //Task<AnimeResponse> anime = response.Result.Content.ReadAsAsync<AnimeResponse>();
                    return anime;
                }

                else
                {
                    return null;
                }
            }
        }
    }
}
