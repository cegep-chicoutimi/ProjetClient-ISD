﻿using AnimeAPI.Models;

namespace Lab_3_Api_mvvm.Model
{
    public class Anime
    {
        public int Id { get; set; }
        public string NomEn { get; set; }
        public string EnJp { get; set; }
        public string Synopsis { get; set; }
        public DateTime DateDebut { get; set; }
        public DateTime DateFin { get; set; }
        public string PosterImage { get; set; }
        public string CoverImage { get; set; }
        public string UrlVideo { get; set; }
        public string Type { get; set; }

        public Anime(Data data)
        {
            Id = data.Id;
            NomEn = data.Attributes.Title.NomEn;
            EnJp = data.Attributes.Title.EnJp;
            Synopsis = data.Attributes.Synopsis;
            DateDebut = data.Attributes.StartDate;
            DateFin = data.Attributes.EndDate;
            PosterImage = data.Attributes.ImagePost.ImageUrl;
            Type = data.Type;
            UrlVideo = data.Attributes.UrlVideo;

            if (data.Attributes.ImageCover != null)
                CoverImage = data.Attributes.ImageCover.ImageUrl;

            else
                CoverImage = PosterImage;
        }
    }
}
