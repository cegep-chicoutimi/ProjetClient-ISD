﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab_3_Api_mvv_.Model;

namespace Lab_3_Api_mvvm.Model
{
    public class RandomUser
    {
        public string Ville { get; set; }
        public string Etat { get; set; }

        public string Pays { get; set; }

        public string CodePostal { get; set; }

        public string Titre { get; set; }
        public string Prenom { get; set; }

        public string Nom { get; set; }

        public string LienPourLImage { get; set; }
        public DateTime Date { get; set; }
        public int Age { get; set; }

        public RandomUser( RandomUserReponse reponse) { 

            Ville = reponse.location.City;
            Etat = reponse.location.Country;
            Pays = reponse.location.Country;
            CodePostal = reponse.location.PostCode;
            Titre = reponse.name.Title;
            Nom = reponse.name.First;
            Prenom = reponse.name.Last;
            LienPourLImage = reponse.picture.Medium;
            Date = reponse.registered.Date;
            Age = reponse.registered.Age;
        
        }
    }
}
