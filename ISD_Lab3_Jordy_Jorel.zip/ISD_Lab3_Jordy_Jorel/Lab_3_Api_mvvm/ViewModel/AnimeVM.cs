﻿using AnimeAPI;
using AnimeAPI.Models;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Lab_3_Api_mvvm.Model;

namespace Lab_3_Api_mvvm.ViewModel
{
    partial class AnimeVM : ObservableObject
    {
        private Anime anime;
        private Task<AnimeResponse> animeResponse;

        [ObservableProperty]
        private int id;

        [ObservableProperty]
        private string nomEn;

        [ObservableProperty]
        private string enJp;

        [ObservableProperty]
        private string synopsis;

        [ObservableProperty]
        private DateTime dateDebut;

        [ObservableProperty]
        private DateTime dateFin;

        [ObservableProperty]
        private string posterImage;

        [ObservableProperty]
        private string coverImage;

        [ObservableProperty]
        private string urlVideo;

        [ObservableProperty]
        private string type;

        public AnimeVM(Task<AnimeResponse> animeResponse)
        {
            this.animeResponse = animeResponse;
            ChargerAnime();
        }

        public async void ChargerAnime()
        {
            AnimeResponse animeResponse = await this.animeResponse;

            if (animeResponse == null)
            {
                Synopsis = "";
                NomEn = "";
                EnJp = "Page Introuvable";
                PosterImage = "https://support.heberjahiz.com/hc/article_attachments/21013105397138";
                CoverImage = "https://1wpserveur-1278.kxcdn.com/wp-content/uploads/2023/07/13315300_5203299.jpg";
                DateDebut = DateTime.Now;
                DateFin = DateTime.Now;
            }

            else
            {
                anime = new Anime(animeResponse.data);

                Synopsis = anime.Synopsis;
                Id = anime.Id;
                NomEn = anime.NomEn;
                EnJp = anime.EnJp;
                DateDebut = anime.DateDebut;
                DateFin = anime.DateFin;
                PosterImage = anime.PosterImage;
                CoverImage = anime.CoverImage;
                Type = anime.Type;
            }
        }

        [RelayCommand]
        public void Suivant()
        {
            Task<AnimeResponse> animeResponse = AnimeProcessor.Connection($"{Id += 1}", Type);
            this.animeResponse = animeResponse;
            ChargerAnime();
        }

        [RelayCommand]
        public void Precedent()
        {
            Task<AnimeResponse> animeResponse = AnimeProcessor.Connection($"{Id -= 1}", Type);
            this.animeResponse = animeResponse;
            ChargerAnime();
        }

        [RelayCommand]
        public void Check(string tag)
        {
            Task<AnimeResponse> animeResponse = AnimeProcessor.Connection($"{Id -= 1}", tag);
            this.animeResponse = animeResponse;
            ChargerAnime();
        }
    }
}
