﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RandomUserAPI;
using CommunityToolkit.Mvvm.ComponentModel;
using Lab_3_Api_mvv_.Model;
using Lab_3_Api_mvvm.Model;
using CommunityToolkit.Mvvm.Input;

namespace Lab_3_Api_mvvm.ViewModel
{
    partial class RandomUserVM : ObservableObject
    {
        private RandomUser randomUser;

        private Task<RandomUserReponses> randomUserReponse;

        [ObservableProperty]
        public string ville ;

        [ObservableProperty]
        public string etat ;

        [ObservableProperty]
        public string pays ;

        [ObservableProperty]
        public string codePostal ;

        [ObservableProperty]
        public string titre ;

        [ObservableProperty]
        public string prenom ;

        [ObservableProperty]
        public string nom ;

        [ObservableProperty]
        public string lienPourLImage ;

        [ObservableProperty]
        public string lienPourImageDefond;

        [ObservableProperty]
        public DateTime date ;

        [ObservableProperty]
        public int age ;


        public RandomUserVM(Task<RandomUserReponses> randomUser) 
        {
            randomUserReponse = randomUser;
            AfficherInfos();
        }

        public async void AfficherInfos() 
        {
            RandomUserReponses randomUserReponse = await this.randomUserReponse;
            randomUser = new RandomUser(randomUserReponse.Results[0]);
            Ville = randomUser.Ville;
            Etat = randomUser.Etat;
            Pays = randomUser.Pays;
            CodePostal = randomUser.CodePostal;
            Titre = randomUser.Titre;
            Prenom = randomUser.Prenom;
            Nom = randomUser.Nom;
            LienPourLImage = randomUser.LienPourLImage;
            Date = randomUser.Date;
            Age = randomUser.Age;

        }

        private bool _estAime;
        public bool EstAime
        {
            get { return _estAime; }
            set
            {
                _estAime = value;
                OnPropertyChanged(nameof(EstAime));
            }
        }


        [RelayCommand]
        public void ChargerUtilisateur()
        {
            Task<RandomUserReponses> randomUserReponseRecu = RandomUserProcessor.LoadRandomUser();
            randomUserReponse = randomUserReponseRecu;
            AfficherInfos();
            ChangementBackgroung( "on");
        }

        [RelayCommand]
        public void ChangementBackgroung(string tag)
        {
            if (tag == "on")
            {
                LienPourImageDefond = LienPourLImage;
               //  = randomUser.LienPourLImage; 
            }
            else
            {
                LienPourImageDefond = "https://fr.freepik.com/photos-gratuite/grunge-wall-texture_1034920.htm#fromView=keyword&page=1&position=26&uuid=6b144907-dfd3-4b02-b66c-93c7d889b3f8&query=Gris+Clair";
            }
        }

    }
}
