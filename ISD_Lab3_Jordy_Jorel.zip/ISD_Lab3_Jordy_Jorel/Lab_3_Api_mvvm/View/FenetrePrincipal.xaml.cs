﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AnimeAPI.Models;
using AnimeAPI;
using Lab_3_Api_mvvm.ViewModel;
using Lab_3_Api_mvvm.Langage;

namespace Lab_3_Api_mvvm.View
{
    /// <summary>
    /// Logique d'interaction pour FenetrePrincipal.xaml
    /// </summary>
    public partial class FenetrePrincipal : Window
    {
        public FenetrePrincipal()
        {
            InitializeComponent();
            UpdateLanguage();
        }

        private void Anime_Click(object sender, RoutedEventArgs e)
        {
            Anime.Visibility = Visibility.Visible;
            RandomUser.Visibility = Visibility.Collapsed;
            PageTransitioner.SelectedIndex = 0;
        }

        private void RandomUser_Click(object sender, RoutedEventArgs e)
        {
            RandomUser.Visibility = Visibility.Visible;
            Anime.Visibility = Visibility.Collapsed;
            PageTransitioner.SelectedIndex = 1;
        }

        private void LanguageSelector_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            UpdateLanguage();
        }

        private void UpdateLanguage()
        {
            var selectedItem = LanguageSelector.SelectedItem as System.Windows.Controls.ComboBoxItem;
            if (selectedItem != null)
            {
                string? cultureCode = selectedItem.Tag.ToString();
                LanguageManager.SetCulture(cultureCode);
                UpdateUI();
            }
        }

        private void UpdateUI()
        {

        }
    }
}
