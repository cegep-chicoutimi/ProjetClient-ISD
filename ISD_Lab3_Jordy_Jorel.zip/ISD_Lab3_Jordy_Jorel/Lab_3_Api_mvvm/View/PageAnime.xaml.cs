﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AnimeAPI.Models;
using AnimeAPI;
using Lab_3_Api_mvvm.ViewModel;

namespace Lab_3_Api_mvvm.View
{
    /// <summary>
    /// Logique d'interaction pour PageAnime.xaml
    /// </summary>
    public partial class PageAnime : UserControl
    {
        public PageAnime()
        {
            ApiHelper.InitializeClient();
            Task<AnimeResponse> animeResponse = AnimeProcessor.Connection("", "anime");
            this.DataContext = new AnimeVM(animeResponse);
            InitializeComponent();
        }
    }
}
