﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AnimeAPI;
using Lab_3_Api_mvv_.Model;
using Lab_3_Api_mvvm.Langage;
using Lab_3_Api_mvvm.ViewModel;
using RandomUserAPI;

namespace Lab_3_Api_mvvm.View
{
    /// <summary>
    /// Logique d'interaction pour PageRandomUser.xaml
    /// </summary>
    public partial class PageRandomUser : UserControl
    {
        public string? CultureCode
        {
            set
            {
                LanguageManager.SetCulture(value);
                UpdateUI();
            }
        }

        public static readonly DependencyProperty CultureCodeProperty =
            DependencyProperty.Register("CultureCode", typeof(string), typeof(PageRandomUser), new PropertyMetadata(null, new PropertyChangedCallback(OnCultureCodeChanged)));

        private static void OnCultureCodeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((PageRandomUser)d).CultureCode = (string)e.NewValue;
        }

        public PageRandomUser()
        {
            RandomUserApiHelper.InitializeClient(); 
            Task<RandomUserReponses> randomUser = RandomUserProcessor.LoadRandomUser();
            this.DataContext = new RandomUserVM(randomUser);
            InitializeComponent();
            UpdateUI();
        }
        private void UpdateUI()
        {
            ville.Text = LanguageManager.GetString("ville");
            nom.Text = LanguageManager.GetString("nom");
            prenom.Text = LanguageManager.GetString("prenom");
            etat.Text = LanguageManager.GetString("etat");
            date.Text = LanguageManager.GetString("date");
            pays.Text = LanguageManager.GetString("pays");
            codePostal.Text = LanguageManager.GetString("codePostal");
            titre.Text = LanguageManager.GetString("titre");
            age.Text = LanguageManager.GetString("age");
            recharger.Content = LanguageManager.GetString("recharger");

        }

        private void recharger_Click(object sender, RoutedEventArgs e)
        {
            actif.IsChecked = true;
        }
    }
}
