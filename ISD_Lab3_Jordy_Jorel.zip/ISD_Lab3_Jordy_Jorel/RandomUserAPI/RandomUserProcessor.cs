﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab_3_Api_mvv_.Model;

namespace RandomUserAPI
{
    public class RandomUserProcessor
    {
        public static Task<RandomUserReponses> LoadRandomUser()
        {
            string url = "/api";


            using (Task<HttpResponseMessage> reponse = RandomUserApiHelper.ClientApi.GetAsync(url))
            {

                if (reponse.Result.IsSuccessStatusCode)
                {

                    Task<RandomUserReponses> randomUser = reponse.Result.Content.ReadAsAsync<RandomUserReponses>();
                    return randomUser;
                }
                else { return null; }
            }
        }
    }
}
