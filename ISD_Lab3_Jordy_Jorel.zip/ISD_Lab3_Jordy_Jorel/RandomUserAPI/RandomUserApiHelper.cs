﻿
using System.Net;
using System.Net.Http.Headers;
using Lab_3_Api_mvv_.Model;

namespace RandomUserAPI
  
{
    public class RandomUserApiHelper
    {
       public static HttpClient ClientApi { get; set; }

        public static void InitializeClient()
        {
            ClientApi = new HttpClient();
            ClientApi.BaseAddress = new Uri("https://randomuser.me");
            ClientApi.DefaultRequestHeaders.Accept.Clear();
            ClientApi.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }
    }
}
