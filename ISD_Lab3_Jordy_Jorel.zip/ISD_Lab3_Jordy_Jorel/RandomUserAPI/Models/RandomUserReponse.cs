﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_Api_mvv_.Model
{
    public class RandomUserReponse
    {
        public Location location {  get; set; }

        public Name name { get; set; }

        public Picture picture { get; set; }

        public Registered registered { get; set; }


    }
}
