﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3_Api_mvv_.Model
{
    public class Registered
    {
        public DateTime Date {  get; set; }
        public int Age { get; set; }
    }
}
